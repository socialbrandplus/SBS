
import React, { useEffect, useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import Portfolio from './components/Portfolio';
import AIConsultant from './components/AIConsultant';
import Contact from './components/Contact';
import Footer from './components/Footer';
import { LanguageProvider } from './contexts/LanguageContext';

const App: React.FC = () => {
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const total = document.documentElement.scrollTop;
      const winScroll = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      setScrollProgress(total / winScroll);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <LanguageProvider>
      {/* Scroll Progress */}
      <div className="fixed top-0 left-0 h-[2px] bg-gradient-to-r from-neon-cyan to-neon-purple z-[100]" style={{ width: `${scrollProgress * 100}%` }}></div>

      <div className="min-h-screen text-white font-sans selection:bg-neon-cyan selection:text-black">
        <Navbar />
        <main>
          <Hero />
          <Services />
          <Portfolio />
          <AIConsultant />
          <Contact />
        </main>
        <Footer />
      </div>
    </LanguageProvider>
  );
};

export default App;
