
import React, { useState, useEffect, useRef } from 'react';
import { generateConsultationResponse } from '../services/geminiService';
import { ChatMessage } from '../types';
import { Send, Cpu, Activity, Minimize2, Terminal, Eye, Aperture, ExternalLink } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const HorusLogo = () => (
  <div className="relative w-8 h-8 flex items-center justify-center">
    <div className="absolute inset-0 bg-neon-cyan/20 blur-md rounded-full"></div>
    <Aperture className="text-neon-cyan relative z-10 animate-spin-slow" size={24} />
    <div className="absolute inset-0 flex items-center justify-center">
      <div className="w-2 h-2 bg-white rounded-full shadow-[0_0_10px_#00f3ff]"></div>
    </div>
  </div>
);

const AIConsultant: React.FC = () => {
  const { t, language } = useLanguage();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMessages([{ role: 'model', text: t.ai.welcome }]);
  }, [t.ai.welcome]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg: ChatMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await generateConsultationResponse(input, language);
      setMessages(prev => [...prev, { role: 'model', text: res }]);
    } catch {
      setMessages(prev => [...prev, { role: 'model', text: t.ai.error, isError: true }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="ai" className="py-24 bg-space-black relative">
      <div className="max-w-4xl mx-auto px-4 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-12">
          <a 
            href="https://gemini.google.com/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 text-neon-cyan mb-4 px-4 py-2 bg-neon-cyan/5 rounded-full border border-neon-cyan/20 hover:bg-neon-cyan/20 hover:shadow-[0_0_20px_rgba(0,243,255,0.4)] transition-all cursor-pointer group"
            title="Go to Gemini AI"
          >
             <HorusLogo />
             <span className="font-mono text-sm tracking-widest uppercase font-bold group-hover:text-white transition-colors">HORUS SYSTEM V.4.0</span>
             <ExternalLink size={12} className="opacity-0 group-hover:opacity-100 transition-opacity" />
          </a>
          <h2 className="text-4xl font-black text-white">{t.ai.title}</h2>
          <p className="text-gray-400 mt-2">{t.ai.subtitle}</p>
        </div>

        {/* Terminal Window */}
        <div className="bg-[#050b14] border border-neon-cyan/30 rounded-lg overflow-hidden shadow-[0_0_50px_rgba(0,243,255,0.1)] relative">
          
          {/* Decorative Scanlines inside Terminal */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[size:100%_2px,3px_100%] pointer-events-none z-20 opacity-50"></div>

          {/* Top Bar */}
          <div className="bg-[#0f172a] p-3 flex justify-between items-center border-b border-white/10">
             <div className="flex items-center gap-3">
               <div className="flex gap-1.5">
                 <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
                 <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
                 <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
               </div>
               <span className="text-xs font-mono text-neon-cyan ml-2 tracking-widest">HORUS_AI_SYSTEM // ONLINE</span>
             </div>
             <Cpu size={16} className="text-neon-cyan animate-spin-slow" />
          </div>

          {/* Chat Body */}
          <div 
            ref={scrollRef}
            className="h-[450px] overflow-y-auto p-6 font-mono text-sm relative z-10 space-y-6 scroll-smooth custom-scrollbar"
          >
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {msg.role === 'model' && (
                  <div className="flex-shrink-0 mt-1 mr-3 rtl:mr-0 rtl:ml-3">
                    <HorusLogo />
                  </div>
                )}
                <div className={`max-w-[85%] p-4 rounded-xl ${
                  msg.role === 'user' 
                    ? 'bg-neon-cyan/10 border border-neon-cyan/30 text-neon-cyan rounded-tr-none rtl:rounded-tr-xl rtl:rounded-tl-none' 
                    : 'bg-white/5 border border-white/10 text-gray-300 rounded-tl-none rtl:rounded-tl-xl rtl:rounded-tr-none'
                }`}>
                  <div className="text-[10px] opacity-50 mb-1 uppercase tracking-wider flex items-center gap-1">
                     {msg.role === 'user' ? '>> USER_INPUT' : 'HORUS_RESPONSE'}
                  </div>
                  <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                 <div className="flex-shrink-0 mt-1 mr-3 rtl:mr-0 rtl:ml-3">
                    <HorusLogo />
                  </div>
                <div className="flex gap-2 text-neon-cyan items-center animate-pulse bg-white/5 p-4 rounded-xl">
                  <Terminal size={16} />
                  <span>ANALYZING REQUEST...</span>
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <form onSubmit={handleSend} className="bg-[#02040a] p-4 border-t border-white/10 relative z-30 flex gap-0">
             <span className="px-3 py-3 text-neon-cyan font-mono">{'>'}</span>
             <input
               type="text"
               value={input}
               onChange={(e) => setInput(e.target.value)}
               placeholder={t.ai.placeholder}
               className="flex-1 bg-transparent text-white font-mono focus:outline-none placeholder-gray-700"
               disabled={loading}
             />
             <button type="submit" disabled={loading} className="text-neon-cyan hover:text-white transition-colors px-4">
                <Send size={18} />
             </button>
          </form>

        </div>
      </div>
    </section>
  );
};

export default AIConsultant;
