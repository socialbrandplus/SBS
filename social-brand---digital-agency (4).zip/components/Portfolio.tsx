
import React, { useState } from 'react';
import { PROJECTS } from '../constants';
import { ProjectCategory, Project } from '../types';
import { X, ExternalLink, Code2, ZoomIn, CheckCircle, Calendar, Smartphone, Monitor, Layout, ArrowRight } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

// --- MOCKUP COMPONENTS ---

const LaptopMockup = ({ image, className = "" }: { image: string, className?: string }) => (
  <div className={`relative mx-auto w-full transition-transform duration-500 ${className}`}>
    <div className="relative bg-[#0d0d0d] rounded-t-xl border-[6px] border-[#0d0d0d] aspect-[16/10] overflow-hidden shadow-2xl ring-1 ring-white/5">
      <img src={image} alt="Project" className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-700" />
      {/* Screen Glare */}
      <div className="absolute inset-0 bg-gradient-to-tr from-white/5 to-transparent pointer-events-none"></div>
    </div>
    <div className="relative bg-[#1a1a1a] h-3 md:h-4 rounded-b-lg shadow mx-auto w-full"></div>
  </div>
);

const PhoneMockup = ({ image, className = "" }: { image: string, className?: string }) => (
  <div className={`relative mx-auto w-[85%] max-w-[220px] aspect-[9/19] bg-[#0d0d0d] rounded-[2rem] border-[6px] border-[#0d0d0d] shadow-2xl overflow-hidden ring-1 ring-white/10 ${className}`}>
    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/3 h-5 bg-black rounded-b-xl z-20"></div>
    <img src={image} alt="App" className="w-full h-full object-cover hover:scale-105 transition-transform duration-700" />
  </div>
);

const CanvasMockup = ({ image, className = "" }: { image: string, className?: string }) => (
  <div className={`relative mx-auto w-[90%] aspect-square bg-white p-3 shadow-xl rounded ${className}`}>
     <div className="w-full h-full overflow-hidden relative border border-gray-100">
        <img src={image} alt="Design" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/paper.png')] opacity-30 pointer-events-none"></div>
     </div>
  </div>
);

const Portfolio: React.FC = () => {
  const [filter, setFilter] = useState<ProjectCategory>(ProjectCategory.ALL);
  const [selected, setSelected] = useState<(Project & { tech?: string[] }) | null>(null);
  const { t, language } = useLanguage();

  const filtered = filter === ProjectCategory.ALL 
    ? PROJECTS 
    : PROJECTS.filter(p => p.category === filter);

  const handleWhatsApp = (projName: string) => {
    const msg = language === 'ar' 
      ? `مرحباً سوشيال براند، لقد أعجبني مشروع "${projName}" وأريد تنفيذ مشروع مشابه.`
      : `Hello Social Brand, I liked the "${projName}" project and I want something similar.`;
    window.open(`https://wa.me/201000251645?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const getMockupForGrid = (project: Project) => {
    switch(project.category) {
      case ProjectCategory.MOBILE:
        return <PhoneMockup image={project.image} />;
      case ProjectCategory.DESIGN:
        return <CanvasMockup image={project.image} />;
      default: // Web, Marketing, Software
        return <LaptopMockup image={project.image} />;
    }
  };

  return (
    <section id="portfolio" className="py-24 relative bg-space-black overflow-hidden">
      
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-neon-purple/5 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center mb-16">
          <span className="text-neon-cyan font-mono text-xs tracking-[0.2em] uppercase font-bold mb-4 block animate-pulse">
            Selected Works
          </span>
          <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
            {t.portfolio.title}
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg leading-relaxed">
            {t.portfolio.subtitle}
          </p>

          {/* Filters */}
          <div className="flex flex-wrap justify-center gap-2 mt-10">
            {Object.values(ProjectCategory).map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-6 py-2 rounded-full text-sm font-bold transition-all duration-300 border ${
                  filter === cat 
                    ? 'bg-neon-cyan text-black border-neon-cyan shadow-[0_0_15px_rgba(0,243,255,0.4)]' 
                    : 'bg-white/5 text-gray-400 border-white/10 hover:border-white/30 hover:text-white'
                }`}
              >
                {t.portfolio.categories[cat]}
              </button>
            ))}
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {filtered.map((project) => (
            <div 
              key={project.id}
              onClick={() => setSelected(project)}
              className="group cursor-pointer perspective-[1000px]"
            >
              <div className="relative bg-[#0a0f1e] border border-white/5 rounded-2xl overflow-hidden transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_10px_30px_rgba(0,0,0,0.5)] hover:border-neon-cyan/30">
                
                {/* Mockup Container */}
                <div className="p-8 bg-gradient-to-b from-[#131b2e] to-[#0a0f1e] min-h-[280px] flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/5 to-transparent opacity-50"></div>
                  
                  {/* The Device Mockup */}
                  <div className="w-full transition-transform duration-500 group-hover:scale-105">
                     {getMockupForGrid(project)}
                  </div>

                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <span className="flex items-center gap-2 bg-white text-black px-6 py-2 rounded-full font-bold text-sm transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                      <ZoomIn size={16} /> {t.portfolio.view_details}
                    </span>
                  </div>
                </div>

                {/* Info */}
                <div className="p-6 border-t border-white/5 relative z-20 bg-[#0a0f1e]">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] font-bold text-neon-cyan uppercase tracking-wider mb-1 block">
                       {t.portfolio.categories[project.category]}
                    </span>
                    <span className="text-xs text-gray-500 font-mono">{project.year}</span>
                  </div>
                  <h3 className="text-xl font-bold text-white group-hover:text-neon-cyan transition-colors">
                    {project.title}
                  </h3>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Project Modal */}
      {selected && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/95 backdrop-blur-md" onClick={() => setSelected(null)}></div>
          
          <div className="relative w-full max-w-6xl bg-[#0a0f1e] border border-white/10 rounded-2xl overflow-hidden shadow-2xl flex flex-col lg:flex-row max-h-[90vh] lg:h-[80vh] animate-fade-in">
            
            <button onClick={() => setSelected(null)} className="absolute top-4 right-4 z-50 bg-black/50 p-2 rounded-full text-white hover:bg-neon-pink transition-colors">
              <X size={24} />
            </button>

            {/* Visual Side */}
            <div className="w-full lg:w-[60%] bg-[#131b2e] relative flex items-center justify-center p-10 lg:p-16 overflow-hidden">
              <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
              <div className="relative z-10 w-full flex justify-center scale-100 lg:scale-110">
                 {selected.category === ProjectCategory.MOBILE 
                   ? <PhoneMockup image={selected.image} className="!w-[260px]" />
                   : selected.category === ProjectCategory.DESIGN 
                     ? <CanvasMockup image={selected.image} className="max-w-md" />
                     : <LaptopMockup image={selected.image} className="max-w-2xl" />
                 }
              </div>
            </div>

            {/* Content Side */}
            <div className="w-full lg:w-[40%] p-8 overflow-y-auto bg-[#0a0f1e] flex flex-col border-l border-white/5">
              
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-2">
                   <CheckCircle size={16} className="text-green-500" />
                   <span className="text-green-500 text-xs font-bold uppercase tracking-wider">Verified Case Study</span>
                </div>
                <h2 className="text-3xl font-black text-white leading-tight mb-4">{selected.title}</h2>
                <p className="text-gray-400 text-sm leading-relaxed border-l-2 border-neon-cyan pl-4 rtl:border-l-0 rtl:border-r-2 rtl:pl-4">
                  {selected.description}
                </p>
              </div>

              {selected.results && (
                <div className="mb-8">
                  <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4">Results & Impact</h4>
                  <div className="grid grid-cols-2 gap-3">
                    {selected.results.map((res, i) => (
                      <div key={i} className="bg-white/5 p-4 rounded-lg border border-white/5">
                        <div className="text-2xl font-mono font-bold text-white mb-1">{res.value}</div>
                        <div className="text-[10px] text-gray-400 uppercase">{res.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {selected.clientReview && (
                <div className="bg-neon-purple/5 p-4 rounded-lg border border-neon-purple/10 mb-8 italic text-gray-300 text-sm">
                  "{selected.clientReview.text}"
                  <div className="mt-2 text-xs font-bold text-neon-purple not-italic">
                    — {selected.clientReview.name}, {selected.clientReview.role}
                  </div>
                </div>
              )}

              <div className="mt-auto">
                <button 
                  onClick={() => handleWhatsApp(selected.title)}
                  className="w-full py-4 bg-neon-cyan text-black font-bold uppercase tracking-wider rounded-lg hover:bg-white transition-all shadow-[0_0_20px_rgba(0,243,255,0.3)] flex items-center justify-center gap-2"
                >
                  <Calendar size={18} />
                  {language === 'ar' ? 'طلب مشروع مماثل' : 'Request Similar Project'}
                </button>
              </div>

            </div>
          </div>
        </div>
      )}

    </section>
  );
};

export default Portfolio;
