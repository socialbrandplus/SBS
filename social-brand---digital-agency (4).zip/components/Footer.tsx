
import React from 'react';
import { Twitter, Instagram, Linkedin, Facebook, Zap, ArrowUp, Mail, MapPin, Phone } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Footer: React.FC = () => {
  const { t } = useLanguage();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative pt-24 pb-10 bg-[#02040a] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 flex items-center justify-center bg-neon-cyan/10 rounded border border-neon-cyan/30 text-neon-cyan">
                 <Zap size={20} className="fill-current" />
              </div>
              <div>
                <h1 className="text-xl font-black text-white font-mono leading-none">
                  SOCIAL<span className="text-neon-cyan">BRAND</span>
                </h1>
                <p className="text-[9px] text-gray-500 font-mono tracking-[0.2em] uppercase">Digital Agency</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              {t.footer.desc}
            </p>
            <div className="flex gap-3">
              {[Facebook, Instagram, Linkedin, Twitter].map((Icon, i) => (
                <a key={i} href="#" className="w-9 h-9 rounded bg-white/5 flex items-center justify-center text-gray-400 hover:bg-neon-cyan hover:text-black transition-all">
                    <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white font-bold mb-6 font-mono border-l-2 border-neon-purple pl-3 rtl:border-l-0 rtl:border-r-2 rtl:pr-3 rtl:pl-0">{t.footer.links}</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              {[
                  {n: t.nav.home, l: '#hero'}, 
                  {n: t.nav.services, l: '#services'}, 
                  {n: t.nav.portfolio, l: '#portfolio'}, 
                  {n: t.nav.consultant, l: '#ai'}
              ].map((link, i) => (
                <li key={i}>
                  <a href={link.l} className="hover:text-neon-cyan transition-colors block py-1">
                    {link.n}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
             <h4 className="text-white font-bold mb-6 font-mono border-l-2 border-neon-pink pl-3 rtl:border-l-0 rtl:border-r-2 rtl:pr-3 rtl:pl-0">{t.footer.contact_info}</h4>
             <ul className="space-y-4 text-sm text-gray-400">
              <li className="flex items-start gap-3">
                 <MapPin size={16} className="text-neon-pink shrink-0 mt-0.5" />
                 <span>{t.contact.address_text}</span>
              </li>
              <li className="flex items-start gap-3">
                 <Phone size={16} className="text-neon-pink shrink-0 mt-0.5" />
                 <span dir="ltr">+20 100 025 1645</span>
              </li>
              <li className="flex items-start gap-3">
                 <Mail size={16} className="text-neon-pink shrink-0 mt-0.5" />
                 <span>info@socialbrand.com</span>
              </li>
            </ul>
          </div>
          
          {/* Map */}
          <div>
             <h4 className="text-white font-bold mb-6 font-mono border-l-2 border-neon-blue pl-3 rtl:border-l-0 rtl:border-r-2 rtl:pr-3 rtl:pl-0">{t.footer.company}</h4>
             <div className="w-full h-32 bg-gray-800 rounded-lg overflow-hidden relative grayscale hover:grayscale-0 transition-all cursor-pointer">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d218360.3637172859!2d31.8019685!3d31.416477!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14f99c0d4a92147f%3A0x6b518292c3038676!2sDamietta%2C%20Damietta%20Governorate!5e0!3m2!1sen!2seg!4v1645551234567!5m2!1sen!2seg" 
                  width="100%" 
                  height="100%" 
                  style={{border:0}} 
                  loading="lazy"
                ></iframe>
             </div>
          </div>

        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-600 text-xs">
            © {new Date().getFullYear()} Social Brand Agency. {t.footer.rights}
          </p>
          <button onClick={scrollToTop} className="w-10 h-10 rounded bg-white/5 flex items-center justify-center text-gray-400 hover:bg-neon-cyan hover:text-black transition-colors">
             <ArrowUp size={18} />
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
