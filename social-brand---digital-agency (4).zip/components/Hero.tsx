
import React from 'react';
import { ArrowRight, ArrowLeft, Zap, ShieldCheck, Rocket } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Hero: React.FC = () => {
  const { t, dir } = useLanguage();
  const Arrow = dir === 'rtl' ? ArrowLeft : ArrowRight;

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center pt-28 pb-12 overflow-hidden">
      
      {/* Subtle Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-neon-purple/10 rounded-full blur-[100px] animate-pulse pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 lg:px-8 relative z-10 w-full grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
        
        {/* Text Side */}
        <div className="text-center lg:text-start rtl:lg:text-right flex flex-col items-center lg:items-start">
          
          <div className="inline-block px-4 py-1.5 rounded-full border border-neon-cyan/30 bg-neon-cyan/10 mb-8 backdrop-blur-sm">
            <span className="text-neon-cyan font-mono text-xs font-bold tracking-widest uppercase flex items-center gap-2">
              <span className="w-2 h-2 bg-neon-cyan rounded-full animate-ping"></span>
              {t.hero.subtitle}
            </span>
          </div>

          <h1 className="text-5xl md:text-7xl font-black text-white leading-[1.1] mb-8 tracking-tight">
            {t.hero.title_start} <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan via-white to-neon-purple drop-shadow-[0_0_15px_rgba(0,243,255,0.3)]">
              {t.hero.title_gradient}
            </span>
          </h1>

          <p className="text-gray-400 text-lg md:text-xl leading-relaxed mb-10 max-w-lg mx-auto lg:mx-0 font-light">
            {t.hero.description}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
            <a 
              href="#portfolio"
              className="px-8 py-4 bg-neon-cyan text-black font-bold text-sm tracking-widest uppercase rounded hover:bg-white transition-all shadow-[0_0_20px_rgba(0,243,255,0.3)] flex items-center justify-center gap-2"
            >
              {t.hero.cta_portfolio}
              <Arrow size={18} />
            </a>
            <a 
              href="#ai"
              className="px-8 py-4 bg-white/5 text-white font-bold text-sm tracking-widest uppercase rounded border border-white/10 hover:bg-white/10 transition-all flex items-center justify-center gap-2"
            >
              {t.hero.cta_ai}
            </a>
          </div>

          <div className="mt-16 pt-8 border-t border-white/5 grid grid-cols-3 gap-8 w-full">
             {[
               { val: '150+', lbl: t.stats.clients },
               { val: '99%', lbl: t.stats.projects },
               { val: '24/7', lbl: 'Support' }
             ].map((s, i) => (
               <div key={i}>
                 <h3 className="text-2xl font-mono font-bold text-white">{s.val}</h3>
                 <p className="text-[10px] text-gray-500 uppercase tracking-widest">{s.lbl}</p>
               </div>
             ))}
          </div>
        </div>

        {/* 3D Visual Side */}
        <div className="hidden lg:block relative h-[600px] perspective-[1000px]">
           <div className="absolute inset-0 animate-float">
              {/* Main Sphere */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-br from-neon-blue/20 to-neon-purple/20 rounded-full border border-white/10 backdrop-blur-md shadow-[0_0_60px_rgba(0,243,255,0.2)] flex items-center justify-center z-10">
                 <Rocket size={80} className="text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.5)]" />
              </div>

              {/* Orbiting Elements */}
              <div className="absolute top-[20%] right-[10%] p-4 bg-black/60 backdrop-blur rounded-xl border border-neon-cyan/30 shadow-lg animate-float animation-delay-1000 flex items-center gap-3 z-20">
                <div className="bg-neon-cyan/20 p-2 rounded"><Zap size={20} className="text-neon-cyan"/></div>
                <div>
                  <div className="h-2 w-20 bg-white/10 rounded mb-1"><div className="h-full w-[80%] bg-neon-cyan animate-pulse rounded"></div></div>
                  <div className="text-[10px] text-gray-400 font-mono">OPTIMIZATION: 98%</div>
                </div>
              </div>

              <div className="absolute bottom-[20%] left-[10%] p-4 bg-black/60 backdrop-blur rounded-xl border border-neon-pink/30 shadow-lg animate-float animation-delay-2000 flex items-center gap-3 z-20">
                 <div className="bg-neon-pink/20 p-2 rounded"><ShieldCheck size={20} className="text-neon-pink"/></div>
                 <div className="text-[10px] text-gray-400 font-mono font-bold">SECURE CODEBASE</div>
              </div>

              {/* Rings */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] border border-white/5 rounded-full animate-spin-slow border-dashed"></div>
           </div>
        </div>

      </div>
    </section>
  );
};

export default Hero;
