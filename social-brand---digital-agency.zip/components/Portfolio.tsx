
import React, { useState } from 'react';
import { PROJECTS } from '../constants';
import { ProjectCategory, Project } from '../types';
import { X, ExternalLink, Code2, ZoomIn, Star, CheckCircle, Calendar, Smartphone, Monitor, Layout } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

// --- Responsive Device Mockups for Grid & Modal ---

const LaptopMockup = ({ image, className = "" }: { image: string, className?: string }) => (
  <div className={`relative mx-auto w-full max-w-[600px] ${className}`}>
    {/* Lid */}
    <div className="relative bg-[#1a1a1a] rounded-t-xl border-[4px] border-[#1a1a1a] aspect-[16/10] overflow-hidden shadow-xl ring-1 ring-white/10">
      {/* Camera Dot */}
      <div className="absolute top-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-black rounded-full z-20 ring-1 ring-gray-700"></div>
      <img src={image} alt="Web Project" className="w-full h-full object-cover object-top" />
      {/* Glare */}
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent pointer-events-none"></div>
    </div>
    {/* Base */}
    <div className="relative bg-[#252525] h-[10px] rounded-b-lg shadow-lg mx-auto w-full flex items-center justify-center">
       <div className="w-16 h-0.5 bg-gray-600/50 rounded-full mt-0.5"></div>
    </div>
  </div>
);

const PhoneMockup = ({ image, className = "" }: { image: string, className?: string }) => (
  <div className={`relative mx-auto w-[160px] md:w-[200px] aspect-[9/19.5] bg-[#1a1a1a] rounded-[2rem] border-[6px] border-[#1a1a1a] shadow-xl overflow-hidden ring-1 ring-white/10 ${className}`}>
    {/* Dynamic Island / Notch */}
    <div className="absolute top-2 left-1/2 -translate-x-1/2 w-16 h-5 bg-black rounded-full z-20 flex items-center justify-center gap-1">
      <div className="w-1 h-1 bg-[#1a1a1a] rounded-full opacity-50"></div>
    </div>
    <img src={image} alt="App Project" className="w-full h-full object-cover rounded-[1.5rem]" />
    {/* Reflection */}
    <div className="absolute inset-0 bg-gradient-to-tr from-white/10 to-transparent pointer-events-none rounded-[1.8rem] z-10"></div>
  </div>
);

const CanvasMockup = ({ image, className = "" }: { image: string, className?: string }) => (
  <div className={`relative mx-auto w-full max-w-[400px] aspect-square bg-gray-100 p-2 shadow-xl rounded-sm ${className}`}>
    <div className="w-full h-full overflow-hidden border border-gray-200 bg-white relative">
       <img src={image} alt="Branding" className="w-full h-full object-cover" />
       {/* Paper Texture Overlay */}
       <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/paper.png')] pointer-events-none"></div>
    </div>
  </div>
);

const Portfolio: React.FC = () => {
  const [filter, setFilter] = useState<ProjectCategory>(ProjectCategory.ALL);
  const [selected, setSelected] = useState<(Project & { tech?: string[] }) | null>(null);
  const { t, language } = useLanguage();

  const filtered = filter === ProjectCategory.ALL 
    ? PROJECTS 
    : PROJECTS.filter(p => p.category === filter);

  const handleWhatsApp = (projName: string) => {
    const msg = `مرحباً، أريد الاستفسار عن تفاصيل مشروع "${projName}"`;
    window.open(`https://wa.me/201000251645?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const getCategoryIcon = (cat: ProjectCategory) => {
    switch (cat) {
      case ProjectCategory.MOBILE: return <Smartphone size={14} />;
      case ProjectCategory.DEVELOPMENT: return <Monitor size={14} />;
      case ProjectCategory.DESIGN: return <Layout size={14} />;
      default: return <Code2 size={14} />;
    }
  };

  const renderMockup = (project: Project, isModal = false) => {
    if (project.category === ProjectCategory.MOBILE) {
      return <PhoneMockup image={project.image} className={isModal ? "w-full !aspect-[9/19.5]" : ""} />;
    } else if (project.category === ProjectCategory.DESIGN) {
      return <CanvasMockup image={project.image} className={!isModal ? "rotate-2 group-hover:rotate-0 transition-transform" : "max-w-[500px]"} />;
    } else {
      // Development AND Marketing use Laptop
      return <LaptopMockup image={project.image} className={isModal ? "max-w-[700px]" : ""} />;
    }
  };

  return (
    <section id="portfolio" className="py-32 relative bg-space-black overflow-hidden">
      
      {/* Background Noise Texture */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none z-0" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='1'/%3E%3C/svg%3E")` }}></div>

      <div className="max-w-7xl mx-auto px-4 lg:px-8 relative z-10">
        
        {/* Centered Header */}
        <div className="text-center mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-neon-cyan/20 bg-neon-cyan/5 mx-auto">
             <Star size={12} className="text-neon-cyan fill-neon-cyan animate-pulse" />
             <span className="text-xs font-mono text-neon-cyan tracking-widest uppercase">World Class Projects</span>
          </div>
          <h2 className="text-4xl md:text-6xl font-black text-white font-mono tracking-tighter">
            GALACTIC <span className="text-neon-purple">PORTFOLIO</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            {t.portfolio.subtitle}
          </p>

          {/* Centered Filters */}
          <div className="flex flex-wrap justify-center gap-2 mt-8">
            {Object.values(ProjectCategory).map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider border transition-all duration-300 ${
                  filter === cat 
                    ? 'bg-white text-black border-white shadow-[0_0_20px_rgba(255,255,255,0.3)] scale-105' 
                    : 'bg-white/5 text-gray-400 border-white/10 hover:border-white/30 hover:text-white hover:bg-white/10'
                }`}
              >
                {t.portfolio.categories[cat]}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map((project) => (
            <div 
              key={project.id}
              onClick={() => setSelected(project)}
              className="group relative rounded-3xl bg-[#0a0f1e] border border-white/5 hover:border-neon-cyan/50 transition-all duration-500 cursor-pointer overflow-hidden flex flex-col h-full hover:shadow-[0_0_30px_rgba(0,243,255,0.15)] hover:-translate-y-2"
            >
              {/* Mockup Showcase Container */}
              <div className="flex-1 bg-gradient-to-br from-[#0f172a] to-[#050b14] relative flex items-center justify-center p-8 overflow-hidden min-h-[300px]">
                 
                 {/* Decorative Grid */}
                 <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:20px_20px]"></div>
                 
                 {/* Render Specific Mockup based on Category */}
                 <div className="transition-transform duration-500 group-hover:scale-105 relative z-10 w-full flex justify-center">
                    {renderMockup(project)}
                 </div>

                 {/* Hover Overlay */}
                 <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/40 backdrop-blur-[2px] z-20">
                    <div className="w-14 h-14 rounded-full bg-neon-cyan text-black flex items-center justify-center shadow-lg transform scale-50 group-hover:scale-100 transition-transform">
                       <ZoomIn size={24} />
                    </div>
                 </div>
              </div>

              {/* Card Footer Info */}
              <div className="p-5 border-t border-white/5 bg-[#0a0f1e] relative z-30">
                <div className="flex items-center justify-between mb-2">
                   <span className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-neon-cyan bg-neon-cyan/10 px-2 py-1 rounded">
                     {getCategoryIcon(project.category)}
                     {t.portfolio.categories[project.category]}
                   </span>
                   <span className="text-gray-500 text-xs font-mono">{project.year}</span>
                </div>
                
                <h3 className="text-lg font-bold text-white leading-tight group-hover:text-neon-cyan transition-colors">
                  {project.title}
                </h3>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Full Screen Modal */}
      {selected && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
          <div className="absolute inset-0 bg-black/95 backdrop-blur-xl animate-fadeIn" onClick={() => setSelected(null)}></div>
          
          <div className="relative w-full max-w-7xl bg-[#0a0f1e] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col lg:flex-row h-[90vh] lg:h-auto lg:max-h-[90vh] animate-scaleIn">
            
            <button 
              className="absolute top-4 right-4 z-50 p-2 bg-black/50 rounded-full text-white hover:bg-neon-pink hover:text-white transition-colors rtl:right-auto rtl:left-4 border border-white/10" 
              onClick={() => setSelected(null)}
            >
              <X size={24} />
            </button>

            {/* Visual Side (Mockup) */}
            <div className="w-full lg:w-[60%] bg-gradient-to-br from-[#1e293b] to-[#020617] relative flex items-center justify-center p-8 lg:p-16 overflow-hidden">
               <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
               <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-neon-cyan/10 rounded-full blur-[100px] pointer-events-none"></div>
               
               <div className="relative z-10 w-full flex justify-center items-center scale-110 lg:scale-125">
                  <div className={selected.category === ProjectCategory.MOBILE ? "w-[240px] md:w-[280px]" : "w-full"}>
                     {renderMockup(selected, true)}
                  </div>
               </div>
            </div>

            {/* Info Side */}
            <div className="w-full lg:w-[40%] p-8 lg:p-10 overflow-y-auto custom-scrollbar bg-[#0a0f1e] flex flex-col">
              
              <div className="flex items-center gap-3 mb-6">
                <div className="flex items-center gap-1.5 bg-green-500/10 text-green-500 px-3 py-1 rounded-full border border-green-500/20">
                  <CheckCircle size={14} className="fill-green-500/20" />
                  <span className="text-[10px] font-bold uppercase tracking-widest">{language === 'ar' ? 'مشروع معتمد' : 'Verified Project'}</span>
                </div>
                <span className="text-xs text-gray-500 font-mono flex items-center gap-1">
                   <Calendar size={12} /> {selected.year}
                </span>
              </div>

              <h3 className="text-2xl md:text-3xl font-black text-white mb-6 leading-tight font-mono">
                {selected.title}
              </h3>

              <div className="space-y-8 flex-1">
                {/* Description */}
                <div>
                  <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 border-b border-white/10 pb-2">
                    {language === 'ar' ? 'نبذة عن المشروع' : 'Project Overview'}
                  </h4>
                  <p className="text-gray-300 leading-relaxed text-sm font-light">
                    {selected.description}
                  </p>
                </div>

                {/* Results Stats */}
                {selected.results && (
                  <div>
                    <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 border-b border-white/10 pb-2">
                       {language === 'ar' ? 'أبرز النتائج' : 'Key Results'}
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                      {selected.results.map((res, idx) => (
                        <div key={idx} className="bg-white/5 p-3 rounded-xl border border-white/5 flex flex-col justify-center">
                          <div className="text-xl font-bold text-white mb-1 font-mono text-glow">{res.value}</div>
                          <div className="text-[10px] text-gray-400 uppercase tracking-wider">{res.label}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Tech Stack */}
                {selected.tech && (
                  <div>
                    <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 border-b border-white/10 pb-2">
                       {language === 'ar' ? 'التقنيات المستخدمة' : 'Technologies'}
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {selected.tech.map((t, i) => (
                        <span key={i} className="px-3 py-1.5 bg-neon-purple/10 border border-neon-purple/20 rounded text-[10px] text-neon-purple font-mono font-bold">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* CTA */}
              <div className="mt-8 pt-6 border-t border-white/10">
                <button 
                  onClick={() => handleWhatsApp(selected.title)}
                  className="w-full py-4 bg-neon-cyan hover:bg-white text-black font-bold text-sm md:text-base rounded-xl transition-all shadow-[0_0_20px_rgba(0,243,255,0.3)] hover:shadow-[0_0_30px_rgba(255,255,255,0.5)] flex items-center justify-center gap-3"
                >
                  <ExternalLink size={18} />
                  {language === 'ar' ? 'ابدأ مشروعك الآن' : 'Start Your Project'}
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};

export default Portfolio;
