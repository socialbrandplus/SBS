import React, { useState, useEffect } from 'react';
import { Menu, X, Globe, Zap, MessageSquare } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const { t, language, toggleLanguage } = useLanguage();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleWhatsApp = () => {
    const msg = language === 'ar' ? "مرحباً، أريد استفساراً عن خدماتكم." : "Hello, I have an inquiry about your services.";
    window.open(`https://wa.me/201000251645?text=${encodeURIComponent(msg)}`, '_blank');
  };

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${
      scrolled 
        ? 'bg-space-black/80 backdrop-blur-xl border-b border-white/10 py-3' 
        : 'bg-transparent py-6'
    }`}>
      <div className="max-w-7xl mx-auto px-4 lg:px-8 flex items-center justify-between">
        
        {/* Logo Area */}
        <div className="flex items-center gap-3 group cursor-pointer" onClick={() => window.scrollTo(0,0)}>
          <div className="relative w-10 h-10 flex items-center justify-center bg-neon-cyan/10 rounded border border-neon-cyan/50 overflow-hidden">
             <div className="absolute inset-0 bg-neon-cyan/20 animate-pulse"></div>
             <Zap className="w-5 h-5 text-neon-cyan relative z-10" />
          </div>
          <div className="leading-none">
            <h1 className="text-2xl font-black tracking-tighter text-white font-mono">
              SOCIAL<span className="text-neon-cyan">BRAND</span>
            </h1>
            <p className="text-[10px] text-gray-400 font-mono tracking-[0.3em] uppercase">Future Agency</p>
          </div>
        </div>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-1 bg-white/5 px-2 py-1.5 rounded-full border border-white/10 backdrop-blur-md">
          {[
            { n: t.nav.home, h: '#hero' },
            { n: t.nav.services, h: '#services' },
            { n: t.nav.portfolio, h: '#portfolio' },
            { n: t.nav.consultant, h: '#ai' }
          ].map((link, i) => (
            <a 
              key={i} 
              href={link.h} 
              className="px-5 py-2 text-sm font-bold text-gray-300 hover:text-white hover:bg-white/10 rounded-full transition-all"
            >
              {link.n}
            </a>
          ))}
        </div>

        {/* Actions */}
        <div className="hidden md:flex items-center gap-4">
          <button 
            onClick={toggleLanguage}
            className="w-10 h-10 flex items-center justify-center rounded-full border border-white/20 text-white hover:bg-white/10 transition-colors"
          >
            <span className="font-mono font-bold text-xs">{language === 'ar' ? 'EN' : 'AR'}</span>
          </button>
          
          <button 
            onClick={handleWhatsApp}
            className="relative px-6 py-2.5 bg-neon-cyan text-space-black font-black text-sm tracking-wide rounded hover:bg-white transition-colors shadow-[0_0_20px_rgba(0,243,255,0.4)] hover:shadow-[0_0_30px_rgba(255,255,255,0.6)] flex items-center gap-2"
          >
            <MessageSquare size={16} />
            {t.nav.quote}
          </button>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-white" onClick={() => setMobileMenu(true)}>
          <Menu size={32} />
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <div className={`fixed inset-0 bg-space-black z-[60] flex flex-col items-center justify-center transition-transform duration-300 ${mobileMenu ? 'translate-x-0' : 'translate-x-full rtl:-translate-x-full'}`}>
        <button className="absolute top-6 right-6 text-gray-400 hover:text-white rtl:left-6 rtl:right-auto" onClick={() => setMobileMenu(false)}>
          <X size={40} />
        </button>
        
        <div className="space-y-8 text-center">
           {[
            { n: t.nav.home, h: '#hero' },
            { n: t.nav.services, h: '#services' },
            { n: t.nav.portfolio, h: '#portfolio' },
            { n: t.nav.consultant, h: '#ai' }
          ].map((link, i) => (
            <a 
              key={i}
              href={link.h}
              onClick={() => setMobileMenu(false)}
              className="block text-4xl font-black text-white hover:text-neon-cyan tracking-tight transition-colors"
            >
              {link.n}
            </a>
          ))}
          
          <div className="flex justify-center gap-6 mt-12">
            <button onClick={toggleLanguage} className="text-xl font-mono border border-white/20 px-6 py-2 rounded text-white">
              {language === 'ar' ? 'English' : 'عربي'}
            </button>
          </div>

           <button onClick={handleWhatsApp} className="mt-8 bg-neon-cyan text-black px-10 py-4 font-bold rounded-full text-xl shadow-lg">
             {t.nav.quote}
           </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;