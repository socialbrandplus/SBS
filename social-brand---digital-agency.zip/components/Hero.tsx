
import React from 'react';
import { ArrowRight, ArrowLeft, PlayCircle, Cpu, ShieldCheck, Rocket } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Hero: React.FC = () => {
  const { t, dir } = useLanguage();
  const Arrow = dir === 'rtl' ? ArrowLeft : ArrowRight;

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24 pb-12">
      
      {/* Cinematic Background Elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-neon-purple/20 rounded-full blur-[120px] animate-pulse"></div>
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-neon-cyan/10 rounded-full blur-[100px]"></div>

      <div className="max-w-7xl mx-auto px-4 lg:px-8 relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        
        {/* Text Content */}
        <div className="text-center lg:text-start rtl:lg:text-right ltr:lg:text-left flex flex-col items-center lg:items-start">
          
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-neon-cyan/30 bg-neon-cyan/5 backdrop-blur mb-8 hover:scale-105 transition-transform">
            <span className="w-2 h-2 bg-neon-cyan rounded-full animate-ping"></span>
            <span className="text-neon-cyan font-mono text-xs uppercase tracking-widest font-bold">
              {t.hero.subtitle}
            </span>
          </div>

          <h1 className="text-5xl md:text-7xl lg:text-8xl font-black text-white leading-[1.1] mb-8 tracking-tighter">
            {t.hero.title_start} <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan via-white to-neon-purple animate-text text-glow">
              {t.hero.title_gradient}
            </span>
          </h1>

          <p className="text-gray-400 text-lg md:text-xl leading-relaxed mb-10 max-w-xl mx-auto lg:mx-0 font-light border-l-2 border-neon-purple/50 pl-6 rtl:border-l-0 rtl:border-r-2 rtl:pl-0 rtl:pr-6">
            {t.hero.description}
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-5 justify-center lg:justify-start w-full lg:w-auto">
            <a 
              href="#portfolio"
              className="group relative px-8 py-4 bg-white text-space-black font-black text-sm tracking-widest uppercase rounded hover:bg-neon-cyan transition-colors duration-300 w-full sm:w-auto text-center shadow-[0_0_20px_rgba(255,255,255,0.2)]"
            >
              <div className="absolute inset-0 border-2 border-white translate-x-1 translate-y-1 group-hover:translate-x-2 group-hover:translate-y-2 transition-transform pointer-events-none rounded"></div>
              <span className="flex items-center justify-center gap-2">
                {t.hero.cta_portfolio}
                <Arrow size={18} />
              </span>
            </a>
            
            <a 
              href="#ai"
              className="flex items-center gap-4 text-white hover:text-neon-cyan transition-colors px-6 py-4 group"
            >
              <div className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center bg-white/5 backdrop-blur group-hover:bg-neon-cyan/20 transition-colors">
                 <PlayCircle size={24} className="fill-current" />
              </div>
              <span className="font-bold tracking-wide text-sm">{t.hero.cta_ai}</span>
            </a>
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-3 gap-8 border-t border-white/10 pt-8 w-full">
            {[
              { k: '100+', l: t.stats.clients },
              { k: '98%', l: t.stats.projects },
              { k: '24/7', l: 'Support' },
            ].map((s, i) => (
              <div key={i} className="text-center lg:text-start rtl:lg:text-right">
                <h3 className="text-3xl font-mono font-bold text-white mb-1">{s.k}</h3>
                <p className="text-[10px] md:text-xs text-gray-500 uppercase tracking-wider">{s.l}</p>
              </div>
            ))}
          </div>
        </div>

        {/* 3D Graphic */}
        <div className="hidden lg:block relative perspective-[1000px] h-[600px]">
          <div className="absolute inset-0 animate-float">
             {/* Central Hub */}
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-gradient-to-br from-neon-blue to-neon-purple rounded-full shadow-[0_0_80px_rgba(188,19,254,0.4)] z-20 flex items-center justify-center border-4 border-white/10 backdrop-blur-md">
                <Rocket size={64} className="text-white drop-shadow-lg" />
             </div>

             {/* Orbit Rings */}
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] border border-white/10 rounded-full animate-[spin_10s_linear_infinite] border-dashed"></div>
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-neon-cyan/20 rounded-full animate-[spin_20s_linear_infinite_reverse]"></div>
             
             {/* Floating Cards */}
             <div className="absolute top-[20%] right-[10%] glass-panel p-4 rounded-xl flex items-center gap-3 animate-float animation-delay-1000 shadow-xl border-neon-cyan/30">
               <div className="bg-neon-cyan/20 p-2 rounded-lg"><Cpu size={20} className="text-neon-cyan" /></div>
               <div className="w-24 h-2 bg-white/10 rounded-full overflow-hidden"><div className="w-[80%] h-full bg-neon-cyan animate-pulse"></div></div>
             </div>

             <div className="absolute bottom-[20%] left-[10%] glass-panel p-4 rounded-xl flex items-center gap-3 animate-float animation-delay-2000 shadow-xl border-neon-pink/30">
               <div className="bg-neon-pink/20 p-2 rounded-lg"><ShieldCheck size={20} className="text-neon-pink" /></div>
               <span className="font-mono text-xs text-neon-pink">SECURE_CONNECTION</span>
             </div>
          </div>
        </div>

      </div>
    </section>
  );
};

export default Hero;
