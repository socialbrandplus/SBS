
import React, { useState } from 'react';
import { Globe, Smartphone, Megaphone, Palette, Code, BarChart3, ArrowUpRight, X, Send, CheckCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const iconMap = {
  Globe, Smartphone, Megaphone, Palette, Code, BarChart: BarChart3
};

interface ServiceFormState {
  name: string;
  company: string;
  q1: string;
  q2: string;
  q3: string;
}

const Services: React.FC = () => {
  const { t, language } = useLanguage();
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [formData, setFormData] = useState<ServiceFormState>({
    name: '', company: '', q1: '', q2: '', q3: ''
  });

  const serviceList = [
    { id: 'web', icon: 'Globe', col: 'neon-cyan' },
    { id: 'app', icon: 'Smartphone', col: 'neon-purple' },
    { id: 'marketing', icon: 'Megaphone', col: 'neon-pink' },
    { id: 'identity', icon: 'Palette', col: 'neon-blue' },
    { id: 'software', icon: 'Code', col: 'neon-cyan' },
    { id: 'data', icon: 'BarChart', col: 'neon-purple' },
  ];

  const handleOpenModal = (id: string) => {
    setActiveModal(id);
    setFormData({ name: '', company: '', q1: '', q2: '', q3: '' });
  };

  const handleCloseModal = () => {
    setActiveModal(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeModal) return;

    // @ts-ignore
    const serviceTitle = t.services.items[activeModal].title;
    // @ts-ignore
    const questions = t.services.form.questions[activeModal];

    const message = language === 'ar' 
      ? `*طلب خدمة جديدة: ${serviceTitle}*\n\n👤 *الاسم:* ${formData.name}\n🏢 *الشركة:* ${formData.company || 'غير محدد'}\n\n📝 *التفاصيل:*\n1️⃣ ${questions.q1}: ${formData.q1}\n2️⃣ ${questions.q2}: ${formData.q2}\n3️⃣ ${questions.q3}: ${formData.q3}`
      : `*New Service Request: ${serviceTitle}*\n\n👤 *Name:* ${formData.name}\n🏢 *Company:* ${formData.company || 'N/A'}\n\n📝 *Details:*\n1️⃣ ${questions.q1}: ${formData.q1}\n2️⃣ ${questions.q2}: ${formData.q2}\n3️⃣ ${questions.q3}: ${formData.q3}`;

    window.open(`https://wa.me/201000251645?text=${encodeURIComponent(message)}`, '_blank');
    handleCloseModal();
  };

  return (
    <section id="services" className="py-32 relative bg-space-black z-20">
      <div className="max-w-7xl mx-auto px-4 lg:px-8">
        
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-6xl font-black text-white mb-6 font-mono tracking-tighter">
             SYSTEM <span className="text-neon-cyan">MODULES</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg font-light">
            {t.services.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {serviceList.map((item, idx) => {
            // @ts-ignore
            const Icon = iconMap[item.icon];
            // @ts-ignore
            const data = t.services.items[item.id];

            return (
              <div 
                key={idx} 
                onClick={() => handleOpenModal(item.id)}
                className="group relative h-[320px] glass-panel rounded-2xl p-8 transition-all duration-500 hover:-translate-y-2 cursor-pointer overflow-hidden"
              >
                {/* Hover Glow */}
                <div className={`absolute -right-20 -top-20 w-40 h-40 bg-${item.col}/20 rounded-full blur-[80px] group-hover:bg-${item.col}/40 transition-all duration-500`}></div>

                {/* Content */}
                <div className="relative z-10 flex flex-col h-full">
                  <div className={`w-14 h-14 rounded-xl bg-white/5 flex items-center justify-center mb-6 text-${item.col} border border-white/10 group-hover:scale-110 transition-transform`}>
                     <Icon size={28} />
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-neon-cyan transition-colors">{data.title}</h3>
                  <p className="text-gray-400 leading-relaxed mb-auto text-sm">{data.desc}</p>

                  <div className="flex items-center justify-between pt-6 border-t border-white/5 mt-4">
                    <span className="font-mono text-xs text-gray-500">MODULE_0{idx + 1}</span>
                    <ArrowUpRight className="text-white opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300 rtl:translate-x-4 rtl:group-hover:translate-x-0" />
                  </div>
                </div>

                {/* Animated Border */}
                <div className="absolute inset-0 border border-white/5 rounded-2xl group-hover:border-neon-cyan/50 transition-colors"></div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Service Request Modal */}
      {activeModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" onClick={handleCloseModal}></div>
          
          <div className="relative w-full max-w-lg bg-[#0a0f1e] border border-neon-cyan/30 rounded-2xl shadow-[0_0_50px_rgba(0,243,255,0.15)] overflow-hidden animate-float">
            
            {/* Holographic Header */}
            <div className="bg-white/5 p-6 border-b border-white/10 flex justify-between items-center relative overflow-hidden">
               <div className="absolute inset-0 bg-neon-cyan/5"></div>
               <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-neon-cyan to-transparent"></div>
               
               <div>
                 <h3 className="text-xl font-bold text-white font-mono flex items-center gap-2">
                   <CheckCircle size={18} className="text-neon-cyan" />
                   {t.services.form.title}
                 </h3>
                 <p className="text-xs text-gray-400 mt-1">{t.services.form.subtitle}</p>
               </div>
               <button onClick={handleCloseModal} className="text-gray-400 hover:text-white transition-colors z-10">
                 <X size={24} />
               </button>
            </div>

            {/* Form Body */}
            <div className="p-6">
              {/* @ts-ignore */}
              <div className="mb-6 p-3 bg-neon-cyan/10 border border-neon-cyan/20 rounded text-neon-cyan text-sm font-bold text-center">
                 {/* @ts-ignore */}
                 {t.services.items[activeModal].title}
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                
                {/* Personal Info */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] uppercase tracking-wider text-gray-500 font-bold mb-1 block">{t.services.form.name}</label>
                    <input 
                      required
                      type="text" 
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                      className="w-full bg-black/40 border border-white/10 rounded p-2.5 text-white focus:border-neon-cyan focus:outline-none transition-colors text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase tracking-wider text-gray-500 font-bold mb-1 block">{t.services.form.company}</label>
                    <input 
                      type="text" 
                      value={formData.company}
                      onChange={e => setFormData({...formData, company: e.target.value})}
                      className="w-full bg-black/40 border border-white/10 rounded p-2.5 text-white focus:border-neon-cyan focus:outline-none transition-colors text-sm"
                    />
                  </div>
                </div>

                <div className="h-[1px] bg-white/10 my-4"></div>

                {/* Specific Questions */}
                {['q1', 'q2', 'q3'].map((qKey) => {
                  // @ts-ignore
                  const label = t.services.form.questions[activeModal][qKey];
                  return (
                    <div key={qKey}>
                       <label className="text-[10px] uppercase tracking-wider text-neon-purple font-bold mb-1 block">{label}</label>
                       <input 
                         required
                         type="text" 
                         // @ts-ignore
                         value={formData[qKey]}
                         // @ts-ignore
                         onChange={e => setFormData({...formData, [qKey]: e.target.value})}
                         className="w-full bg-black/40 border border-white/10 rounded p-2.5 text-white focus:border-neon-purple focus:outline-none transition-colors text-sm"
                       />
                    </div>
                  );
                })}

                <button 
                  type="submit" 
                  className="w-full mt-6 bg-neon-cyan text-black font-bold py-3.5 rounded-lg hover:bg-white transition-all shadow-[0_0_20px_rgba(0,243,255,0.3)] flex items-center justify-center gap-2"
                >
                  <Send size={18} />
                  {t.services.form.submit}
                </button>

              </form>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};

export default Services;
