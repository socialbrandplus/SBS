
import React, { useState } from 'react';
import { Mail, Phone, MessageCircle, MapPin } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Contact: React.FC = () => {
  const { t, language } = useLanguage();
  const [form, setForm] = useState({ name: '', email: '', msg: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = language === 'ar'
      ? `*رسالة تواصل جديدة من الموقع*\n\n👤 الاسم: ${form.name}\n📧 الايميل: ${form.email}\n📝 الرسالة: ${form.msg}`
      : `*New Contact Message*\n\n👤 Name: ${form.name}\n📧 Email: ${form.email}\n📝 Message: ${form.msg}`;
    window.open(`https://wa.me/201000251645?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <section id="contact" className="py-24 relative overflow-hidden bg-space-black border-t border-white/5">
      
      {/* Decorative World Map Effect */}
      <div className="absolute top-0 right-0 w-full h-full opacity-10 pointer-events-none bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-neon-purple/20 via-transparent to-transparent"></div>

      <div className="max-w-7xl mx-auto px-4 lg:px-8 relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16">
        
        {/* Info */}
        <div className="flex flex-col justify-center">
           <h2 className="text-5xl font-black text-white mb-8 tracking-tighter">
             {t.contact.title}
           </h2>
           <p className="text-gray-400 text-lg mb-12 border-l-2 border-neon-cyan pl-6 rtl:border-l-0 rtl:border-r-2 rtl:pl-0 rtl:pr-6">
             {t.contact.subtitle}
           </p>

           <div className="space-y-6">
             <div className="glass-panel p-6 rounded-xl flex items-center gap-4 hover:border-neon-cyan/50 transition-colors cursor-pointer group" onClick={() => window.open('https://wa.me/201000251645', '_blank')}>
                <div className="bg-neon-cyan/10 p-3 rounded-full text-neon-cyan group-hover:scale-110 transition-transform"><Phone size={24} /></div>
                <div>
                  <div className="text-xs text-gray-500 font-bold uppercase">{t.contact.phone}</div>
                  <div className="text-xl text-white font-mono font-bold" dir="ltr">+20 100 025 1645</div>
                </div>
             </div>
             
             <div className="glass-panel p-6 rounded-xl flex items-center gap-4 hover:border-neon-purple/50 transition-colors">
                <div className="bg-neon-purple/10 p-3 rounded-full text-neon-purple"><Mail size={24} /></div>
                <div>
                  <div className="text-xs text-gray-500 font-bold uppercase">{t.contact.email}</div>
                  <div className="text-xl text-white font-mono">info@socialbrand.com</div>
                </div>
             </div>

             <div className="glass-panel p-6 rounded-xl flex items-center gap-4 hover:border-neon-pink/50 transition-colors">
                <div className="bg-neon-pink/10 p-3 rounded-full text-neon-pink"><MapPin size={24} /></div>
                <div>
                  <div className="text-xs text-gray-500 font-bold uppercase">{t.contact.location}</div>
                  {/* @ts-ignore */}
                  <div className="text-xl text-white font-mono">{t.contact.address_text}</div>
                </div>
             </div>
           </div>
        </div>

        {/* Form */}
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-br from-neon-cyan/20 to-neon-purple/20 blur-[50px] -z-10 rounded-full"></div>
          
          <form onSubmit={handleSubmit} className="bg-space-black/80 backdrop-blur-xl p-8 rounded-2xl border border-white/10 shadow-2xl">
             <div className="space-y-6">
               <div>
                 <label className="text-xs text-neon-cyan font-bold uppercase mb-2 block tracking-wider">{t.contact.form.name}</label>
                 <input 
                   type="text" 
                   value={form.name}
                   onChange={e => setForm({...form, name: e.target.value})}
                   required
                   className="w-full bg-[#0a0f1e] border border-gray-700 rounded-lg p-4 text-white focus:outline-none focus:border-neon-cyan transition-colors"
                 />
               </div>
               <div>
                 <label className="text-xs text-neon-cyan font-bold uppercase mb-2 block tracking-wider">{t.contact.form.email}</label>
                 <input 
                   type="email" 
                   value={form.email}
                   onChange={e => setForm({...form, email: e.target.value})}
                   required
                   className="w-full bg-[#0a0f1e] border border-gray-700 rounded-lg p-4 text-white focus:outline-none focus:border-neon-cyan transition-colors"
                 />
               </div>
               <div>
                 <label className="text-xs text-neon-cyan font-bold uppercase mb-2 block tracking-wider">{t.contact.form.message}</label>
                 <textarea 
                   rows={4}
                   value={form.msg}
                   onChange={e => setForm({...form, msg: e.target.value})}
                   required
                   className="w-full bg-[#0a0f1e] border border-gray-700 rounded-lg p-4 text-white focus:outline-none focus:border-neon-cyan transition-colors resize-none"
                 />
               </div>

               <button type="submit" className="w-full bg-[#25D366] hover:bg-white hover:text-[#25D366] text-white font-bold py-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-lg">
                  <MessageCircle size={24} />
                  {t.contact.form.submit}
               </button>
             </div>
          </form>
        </div>

      </div>
    </section>
  );
};

export default Contact;
