
import React from 'react';
import { Rocket, Twitter, Instagram, Linkedin, Facebook, Zap, ArrowUp, Mail, MapPin, Phone } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Footer: React.FC = () => {
  const { t, language } = useLanguage();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleWhatsApp = () => {
    window.open('https://wa.me/201000251645', '_blank');
  };

  return (
    <footer className="relative pt-32 pb-10 overflow-hidden bg-space-black border-t border-white/5">
      
      {/* Background Ambience */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-[500px] bg-neon-purple/5 rounded-full blur-[120px] pointer-events-none"></div>

      {/* Floating CTA Banner */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] max-w-5xl z-20">
        <div className="glass-panel p-8 md:p-12 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-8 shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-neon-cyan/20 relative overflow-hidden group">
           {/* Animated Shine */}
           <div className="absolute top-0 -left-[100%] w-1/2 h-full bg-gradient-to-r from-transparent via-white/10 to-transparent skew-x-12 group-hover:left-[200%] transition-all duration-1000 ease-in-out"></div>
           
           <div className="text-center md:text-start rtl:md:text-right">
             <h3 className="text-2xl md:text-4xl font-black text-white mb-2">{t.footer.cta_title}</h3>
             <p className="text-gray-400">{t.contact.subtitle}</p>
           </div>
           
           <button 
             onClick={handleWhatsApp}
             className="whitespace-nowrap px-8 py-4 bg-neon-cyan text-black font-bold text-lg rounded-xl shadow-[0_0_20px_rgba(0,243,255,0.4)] hover:bg-white transition-all hover:scale-105 hover:shadow-[0_0_40px_rgba(255,255,255,0.5)]"
           >
             {t.footer.cta_btn}
           </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 pt-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          
          {/* Brand Column */}
          <div className="space-y-6">
            <div className="flex items-center gap-3 cursor-pointer" onClick={scrollToTop}>
              <div className="w-10 h-10 flex items-center justify-center bg-neon-cyan/10 rounded border border-neon-cyan/50 text-neon-cyan">
                 <Zap size={20} className="fill-current" />
              </div>
              <div>
                <h1 className="text-xl font-black text-white font-mono leading-none">
                  SOCIAL<span className="text-neon-cyan">BRAND</span>
                </h1>
                <p className="text-[9px] text-gray-500 font-mono tracking-[0.2em] uppercase">Future Agency</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed max-w-xs">
              {t.footer.desc}
            </p>
            <div className="flex gap-3">
              {[Facebook, Instagram, Linkedin, Twitter].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 hover:bg-neon-cyan hover:text-black hover:border-neon-cyan transition-all duration-300">
                    <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          {/* Links Column */}
          <div>
            <h4 className="text-white font-mono font-bold mb-8 flex items-center gap-2">
               <span className="w-8 h-[2px] bg-neon-purple"></span> {t.footer.links}
            </h4>
            <ul className="space-y-3">
              {[
                  {n: t.nav.home, l: '#hero'}, 
                  {n: t.nav.services, l: '#services'}, 
                  {n: t.nav.portfolio, l: '#portfolio'}, 
                  {n: t.nav.consultant, l: '#ai'}
              ].map((link, i) => (
                <li key={i}>
                  <a href={link.l} className="text-gray-400 hover:text-neon-cyan transition-colors flex items-center gap-2 text-sm group">
                    <span className="w-1 h-1 bg-neon-cyan rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></span>
                    {link.n}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info Column */}
          <div>
             <h4 className="text-white font-mono font-bold mb-8 flex items-center gap-2">
               <span className="w-8 h-[2px] bg-neon-pink"></span> {t.footer.contact_info}
            </h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-gray-400 text-sm">
                 <MapPin size={18} className="text-neon-pink shrink-0" />
                 <span>{t.contact.address_text}</span>
              </li>
              <li className="flex items-start gap-3 text-gray-400 text-sm">
                 <Phone size={18} className="text-neon-pink shrink-0" />
                 <span dir="ltr">+20 100 025 1645</span>
              </li>
              <li className="flex items-start gap-3 text-gray-400 text-sm">
                 <Mail size={18} className="text-neon-pink shrink-0" />
                 <span>info@socialbrand.us.cc</span>
              </li>
            </ul>
          </div>
          
           {/* Legal / Map Placeholder */}
           <div>
             <h4 className="text-white font-mono font-bold mb-8 flex items-center gap-2">
               <span className="w-8 h-[2px] bg-neon-blue"></span> {t.footer.company}
            </h4>
            <div className="w-full h-32 bg-white/5 rounded-xl border border-white/10 flex items-center justify-center relative overflow-hidden group cursor-pointer" onClick={() => window.open('https://maps.google.com', '_blank')}>
               <div className="absolute inset-0 bg-[url('https://assets.codepen.io/1462889/map-dark.png')] bg-cover opacity-50 grayscale group-hover:grayscale-0 transition-all"></div>
               <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors"></div>
               <div className="relative z-10 flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider">
                 <MapPin size={14} className="text-neon-cyan" /> Locate Us
               </div>
            </div>
            <div className="flex gap-4 mt-6 text-xs text-gray-500">
               <a href="#" className="hover:text-white transition-colors">Privacy</a>
               <a href="#" className="hover:text-white transition-colors">Terms</a>
               <a href="#" className="hover:text-white transition-colors">Sitemap</a>
            </div>
           </div>

        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-600 text-xs text-center md:text-start">
            © {new Date().getFullYear()} Social Brand Agency. {t.footer.rights}
          </p>
          
          <button 
            onClick={scrollToTop}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-neon-cyan hover:text-black hover:-translate-y-1 transition-all"
          >
             <ArrowUp size={18} />
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
