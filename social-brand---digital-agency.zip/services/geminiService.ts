
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateConsultationResponse = async (userMessage: string, lang: 'ar' | 'en'): Promise<string> => {
  try {
    const isArabic = lang === 'ar';
    
    const systemInstruction = isArabic ? `
      أنت "حورس AI"، المستشار الذكي لشركة "سوشيال براند" (Social Brand) في مصر، دمياط.
      الشركة متخصصة في: البرمجة (مواقع وتطبيقات)، التسويق الإلكتروني، وتصميم الهويات.
      
      تعليمات الرد:
      1. تحدث باحترافية وودية.
      2. إذا أبدى العميل رغبة جادة في الشراء أو طلب تفاصيل الأسعار، وجهه فوراً للتواصل عبر واتساب على الرقم: 01000251645.
      3. يمكنك قول: "لتقديم عرض سعر دقيق، يفضل التواصل مباشرة مع فريق المبيعات عبر واتساب: 01000251645".
      4. كن مختصراً ومفيداً.
    ` : `
      You are "Horus AI", the intelligent consultant for "Social Brand" agency in Damietta, Egypt.
      Specialties: Web/App Development, Digital Marketing, Branding.
      
      Instructions:
      1. Be professional and friendly.
      2. If the user shows intent to purchase or asks for prices, explicitly direct them to WhatsApp at: +201000251645.
      3. You can say: "For an accurate quote, please contact our sales team directly on WhatsApp: +201000251645".
      4. Keep answers concise.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: userMessage,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      },
    });

    return response.text || (isArabic ? "عذراً، لم أتمكن من معالجة طلبك." : "Sorry, I could not process your request.");
  } catch (error) {
    console.error("Gemini API Error:", error);
    return lang === 'ar' 
      ? "واجهنا مشكلة تقنية بسيطة، يرجى التواصل معنا عبر الهاتف." 
      : "We encountered a technical issue, please contact us by phone.";
  }
};
